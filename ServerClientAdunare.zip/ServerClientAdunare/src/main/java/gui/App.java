package gui;

import client.RequestProcessor;

import javax.swing.*;
import javax.swing.plaf.OptionPaneUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class App {
    public static void main(String[] args) {
        LayoutManager layOut = new GridLayout(4, 1);
        final Frame f = new Frame();
        f.setLayout(layOut);
        final TextField tfNumberA = new TextField();
        tfNumberA.setSize(new Dimension(100, 10));
        final TextField tfNumberB = new TextField();
        tfNumberB.setPreferredSize(new Dimension(200, 50));

        f.add(tfNumberA);
        f.add(tfNumberB);
        Button bttn = new Button("Calculeaza");
        f.add(bttn);
        final Label labelRezultat = new Label("Rezultat: ");
        f.add(labelRezultat);
        bttn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RequestProcessor processor = new RequestProcessor(6666);
                try {
                    labelRezultat.setText(String.valueOf(processor.add(Double.parseDouble(tfNumberA.getText()), Double.parseDouble(tfNumberB.getText()))));
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Conexiunea cu serverul nu a putut fi stabilita.");
                } catch(NumberFormatException | NullPointerException numberProblem) {
                    JOptionPane.showMessageDialog(null, "Numere invalide.");
                }
            }
        });
        f.setSize(300, 300);
        f.setVisible(true);
    }
}
